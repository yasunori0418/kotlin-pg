package dev.yasunori0418.playground

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class PlaygroundApplicationTests {

	@Test
	fun contextLoads() {
	}

}
